import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-management',
  templateUrl: './view-management.component.html',
  styleUrls: ['./view-management.component.css']
})
export class ViewManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
