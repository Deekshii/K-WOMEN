import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { LibrarianComponent } from './librarian/librarian.component';
import { StudentComponent } from './student/student.component';
import { ViewLibrarianComponent } from './librarian/view-librarian/view-librarian.component';
import { CreateLibrarianComponent } from './librarian/create-librarian/create-librarian.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';
import { ManagementComponent } from './management/management.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';


const routes: Routes = [
 
  // { path: 's_edit',    component: ViewComponent},
  { path: 'l_create',    component: CreateLibrarianComponent },
  { path: 'l_edit',    component:  ViewLibrarianComponent},
  { path: 's_edit',  component:  ViewStudentComponent},
  { path: 'm_edit',  component:  ViewManagementComponent},
  { path: 'm',  component:  ManagementComponent},
  { path: 's',  component:  StudentComponent},
  { path: 'l',    component:  LibrarianComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
