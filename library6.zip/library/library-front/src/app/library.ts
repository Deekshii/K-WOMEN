export class Library {

    booksavailable: string;
    studentname: string;
    dateofissue: Date;
    subjectname: string;
    studentemail: string;
    studentclass: string;
    studentbranch:string;
    studentsection: string;
}

 