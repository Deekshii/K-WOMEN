import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';

import { ViewManagementComponent } from './management/view-management/view-management.component';
import { FacultyComponent } from './faculty/faculty.component';
import { ViewFacultyComponent } from './faculty/view-faculty/view-faculty.component';
import { CreateFacultyComponent } from './faculty/create-faculty/create-faculty.component';


@NgModule({
  declarations: [
    AppComponent,
    ViewFacultyComponent,
    ManagementComponent,
    StudentComponent,
    ViewStudentComponent,
    CreateFacultyComponent,
    ViewManagementComponent,
    FacultyComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
