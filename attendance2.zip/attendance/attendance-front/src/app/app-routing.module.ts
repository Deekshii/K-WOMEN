import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StudentComponent } from './student/student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';
import { FacultyComponent } from './faculty/faculty.component';
import { ViewFacultyComponent } from './faculty/view-faculty/view-faculty.component';
import { CreateFacultyComponent } from './faculty/create-faculty/create-faculty.component';
import { ManagementComponent } from './management/management.component';


const routes: Routes = [
  { path: 'f_create',    component: CreateFacultyComponent },
  { path: 'f_edit',    component: ViewFacultyComponent},
  { path: 'm_edit',    component: ViewManagementComponent},
  { path: 's_edit',    component: ViewStudentComponent},
  { path: 'm',    component: ManagementComponent },
  { path: 'f',    component: FacultyComponent },
  { path: 's',    component: StudentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
