import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Attendance } from 'src/app/attendance';

@Component({
  selector: 'app-create-faculty',
  templateUrl: './create-faculty.component.html',
  styleUrls: ['./create-faculty.component.css']
})
export class CreateFacultyComponent implements OnInit {

  stud: Attendance= {
    studentname: "",
    studentclass: "",
    studentbranch: "",
      studentsection: "",
      studentid: "",
      sessionsattended: "",
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}