import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-view-managemen',
  templateUrl: './view-managemen.component.html',
  styleUrls: ['./view-managemen.component.css']
})
export class ViewManagemenComponent implements OnInit {

  
  stud 
  val:boolean = true ; 
  expandedIndex: any
  constructor(private service: ApiService) { }

  delete(val){
    var v={
      "_id":val._id
    }
    console.log(v)
    this.service.del(v).subscribe(res => {
      console.log(res)   
   })
  }
  ngOnInit() {
    console.log('hello');
   this.getAllFaculty();
  }
//gets data from db
  getAllFaculty () {
    console.log('hi');
    this.service.getfaculty().subscribe((res: any) => {
      this.stud = res
      console.log(res);
    }, err => {
      console.log(err);
    })
  }


// //edit the data
//     public edit(data, index) {
//     this.expandedIndex = index;
//   }
//   //saves edited data
//   public save(data) {
//      this.service.add(data).subscribe((data) => {
//        console.log(data)
//        this.val = true
//      })
//     } 



}

