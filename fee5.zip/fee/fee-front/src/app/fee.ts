export class Fee {
    studentname: string;
  studentclass: string;
  studentbranch: string;
    studentsection: String;
    studentid: string;
    studentfeedetails: string;
}
