import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { ManagementComponent } from './management/management.component';

import { CreateComponent } from './officer/create/create.component';
import { OfficerComponent } from './officer/officer.component';
import { ViewComponent } from './officer/view/view.component';
import { ViewManagemenComponent } from './management/view-managemen/view-managemen.component';


const routes: Routes = [
  { path: 'm',    component: ManagementComponent},
  { path: 'm_edit',    component: ViewManagemenComponent},
  { path: 'o',    component:OfficerComponent},
  { path: 'o_create',    component: CreateComponent },
  { path: 'o_edit',    component: ViewComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
