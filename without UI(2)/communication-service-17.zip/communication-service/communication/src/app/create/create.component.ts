import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { communication } from '../communication';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  stud : communication = {
    
    eventnotification: "",
    description : "",
    examnotification : "",
    e_description : "",
  
  };

  constructor( private service: ApiService) { }

  ngOnInit() {
  }
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}
