export class communication {
    eventnotification: String;
    description : String;
    examnotification : String;
    e_description : String;
 }
 