

  var express = require('express');
var router = express.Router();
var createCommuniction = require('../models/C-stud');
router.post('/create', function(req,res,next) {
      var createcommuniction = new createCommuniction({
      eventnotification: req.body.eventnotification,
      description: req.body.description,
      examnotification:req.body. examnotification,
      e_description: req.body.e_description,
});
  
    let promise = createcommuniction.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
  
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;
