export class Student {
    studentname: string;
    fathername: string;
    mothername: string;
    studentid: Number;
    studentdob:Date;
  studentclass: string;
  studentbranch: string;
    studentsection: String;
    studentacademicpercentage: Number;
    yearofpassing: Date;
    student10thpercentage: Number;
    studentintermediatepercentage: Number;
    studentfeedetails: string;
}
 