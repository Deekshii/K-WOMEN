import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Student } from 'src/app/student';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  stud: Student= {
    studentname: "",
    fathername: "",
    mothername: "",
    studentid: null,
    studentdob: null,
    studentclass: "",
    studentbranch: "",
      studentsection: "",
      studentacademicpercentage: null,
      yearofpassing: null,
      student10thpercentage: null,
      studentintermediatepercentage:null, 
      studentfeedetails:"",
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}
