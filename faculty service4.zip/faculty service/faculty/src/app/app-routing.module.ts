import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { CreateFacultyComponent } from './create-faculty/create-faculty.component';
// import { ViewFacultyComponent } from './view-faculty/view-faculty.component';
import { CreateComponent } from './management/create/create.component';
import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';
import { FacultyComponent } from './faculty/faculty.component';

import { ViewComponent } from './management/view/view.component';
import { CreateFacultyComponent } from './faculty/create-faculty/create-faculty.component';
import { ViewFacultyComponent } from './faculty/view-faculty/view-faculty.component';
import { CreateStudentComponent } from './student/create-student/create-student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';


const routes: Routes = [
   { path: 'm_create',    component: CreateComponent },
   { path: 'm_edit',    component: ViewComponent}, 
   { path: 'f_create',    component: CreateFacultyComponent },
   { path: 'f_edit',    component: ViewFacultyComponent},
   { path: 's_create',    component: CreateStudentComponent },
   { path: 's_edit',    component: ViewStudentComponent},
  { path: 'f',    component: FacultyComponent },
  { path: 'm',    component: ManagementComponent },
  { path: 's',    component: StudentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
