import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Faculty } from 'src/app/faculty';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {


    stud : Faculty= {
      email : "",
      phonenumber : null,
      firstname: "",
      lastname: "",
      dateofbirth : null,
      age:null ,
      address: "",
      speciliazedin : "",
      department : "",
      dateofjoining : null,
      gender : "",
      collegename: "",
      
    };
    constructor(private service: ApiService) { }
    ngOnInit() {
    } 
    create() {
      console.log(this.stud);
     this.service.create(this.stud).subscribe(res => {
        console.log(res)     
     })
    }
  
  }
  
  