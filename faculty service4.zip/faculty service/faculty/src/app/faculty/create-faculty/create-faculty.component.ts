import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Faculty } from 'src/app/faculty';

@Component({
  selector: 'app-create-faculty',
  templateUrl: './create-faculty.component.html',
  styleUrls: ['./create-faculty.component.css']
})
export class CreateFacultyComponent implements OnInit {
  stud : Faculty= {
    email : "",
    phonenumber : null,
    firstname: "",
    lastname: "",
    dateofbirth : null,
    age:null ,
    address: "",
    speciliazedin : "",
    department : "",
    dateofjoining : null,
    gender : "",
    collegename: "",
    
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}


