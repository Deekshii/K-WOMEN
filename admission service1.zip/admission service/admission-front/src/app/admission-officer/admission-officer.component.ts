import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admission-officer',
  templateUrl: './admission-officer.component.html',
  styleUrls: ['./admission-officer.component.css']
})
export class AdmissionOfficerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
