export class Admission {
    studentname: string;
    fathername: string;
    mothername: string;
    student10thdetails: String;
    studentintermediatedetails: string;
    dateofbirth : Date;
    joiningbranch: string;
}
