import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { AdmissionOfficerComponent } from './admission-officer/admission-officer.component';
import { StudentComponent } from './student/student.component';
import { ViewComponent } from './student/view/view.component';
import { CreateAdmissionComponent } from './admission-officer/create-admission/create-admission.component';
import { ViewAdmissionComponent } from './admission-officer/view-admission/view-admission.component';
import { ManagementComponent } from './management/management.component';
import { CreateComponent } from './management/create/create.component';



const routes: Routes = [

  { path: 's_edit',    component: ViewComponent}, 
  { path: 'a_create',    component:CreateAdmissionComponent },
  { path: 'm_edit',    component: ViewComponent},
  { path: 'm_create',    component: CreateComponent},
  { path: 'a_edit',    component: ViewAdmissionComponent},
  { path: 's',    component:StudentComponent },
  { path: 'a',    component: AdmissionOfficerComponent},
  { path: 'm',    component: ManagementComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
