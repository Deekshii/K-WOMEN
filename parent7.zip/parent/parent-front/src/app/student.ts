export class Student {
    studentname: string;
    fathername: string;
    studentid: Number;
  studentclass: string;
  studentbranch: string;
    studentsection: String;
    studentacademicpercentage: Number;
    studentfeedetails: string;
}
 