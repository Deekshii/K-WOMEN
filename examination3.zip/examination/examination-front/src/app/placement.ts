export class Placement {
    studentname: string;
  studentclass: string;
  studentbranch: string;
    studentsection: String;
    studentid: string;
    studentacademicpercentage: string;
    examstimetable: string;
}
 