import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';

import { OfficerComponent } from './officer/officer.component';
import { CreateOfficerComponent } from './officer/create-officer/create-officer.component';
import { ViewOfficerComponent } from './officer/view-officer/view-officer.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';


@NgModule({
  declarations: [
    AppComponent,
 
    ManagementComponent,
    StudentComponent,
    ViewStudentComponent,
   
    OfficerComponent,
    CreateOfficerComponent,
    ViewOfficerComponent,
    ViewManagementComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
